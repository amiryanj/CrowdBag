#include "crowdbag.hpp"
#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char *argv[])
{
    float radius = 0.3;
    float speed = 1.3;
    float time_horizon = 2;
    float neighbor_dist = 5;

    float ratio = 5; // use this to scale up the initial distance to collision

    string simType= "rvo2";
    if(argc > 1) simType = argv[1];

    CrowdSim sim(simType);
    // CrowdSim sim("rvo2");
    // CrowdSim sim("helbing");
    // CrowdSim sim("vision");
    // CrowdSim sim("boids");

    int n_peds = 2;

    sim.init(n_peds);
    sim.setTime(0);

    // initial positions
    sim.setPosition(0, -ratio, 0);
    sim.setGoal(0, ratio, 0);
    sim.setAgentRadius(0, radius);
    sim.setAgentSpeed(0, speed);
    if(simType.compare("rvo2") == 0 || simType.compare("powerlaw") == 0)
    {
        sim.setAgentTimeHorizon(0, time_horizon);
        sim.setAgentNeighborDist(0, neighbor_dist);
    }


    sim.setPosition(1, ratio*cos(3.141592/4), ratio*sin(3.141592/4));
    sim.setGoal(1, ratio*cos(5 * 3.141592/4 ), ratio*sin(5 * 3.141592/4));
    sim.setAgentRadius(1, radius);
    sim.setAgentSpeed(1, speed);
    if(simType.compare("rvo2") == 0 || simType.compare("powerlaw") == 0)
    {
        sim.setAgentTimeHorizon(1, time_horizon);
        sim.setAgentNeighborDist(1, neighbor_dist);
    }

    // Simulation
    float dt = 0.05;
    float total_time = 20; //seconds

    for(int k=0; k < total_time/dt; k++) {

        float t = dt * k;

        sim.doStep(dt);

        printf("%.3f", t);

        for(int i=0; i<n_peds; i++) {
            float px_i = sim.getCenterxNext(i);
            float py_i = sim.getCenteryNext(i);
            printf(",%.3f,%.3f", px_i, py_i);
        }
        std::cout << "\r";


    }

}
